package com.student.bean;

import java.io.Serializable;

public class Student implements Serializable{

	private String StudentName;
	private String StudentDept;
	private String Studentmarks;
	private String mobileNumber;
	private String percentage;
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	public String getStudentDept() {
		return StudentDept;
	}
	public void setStudentDept(String studentDept) {
		StudentDept = studentDept;
	}
	public String getStudentmarks() {
		return Studentmarks;
	}
	public void setStudentmarks(String studentmarks) {
		Studentmarks = studentmarks;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	
	
	
}
