package com.student.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.student.bean.Student;

/**
 * Servlet implementation class StudentController
 */
@WebServlet("/StudentController")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("stdName");
		String dept = request.getParameter("stdDept");
		String marks = request.getParameter("std12thMarks");
		String mobileNum = request.getParameter("stdMoNum");
		String percentage = request.getParameter("stdPer");
		
		Student student = new Student();
		student.setStudentName(name);
		student.setStudentDept(dept);
		student.setStudentmarks(marks);
		student.setMobileNumber(mobileNum);
		student.setPercentage(percentage);
		
		if(isvalidate(student)) {
			HttpSession session = request.getSession();
			session.setAttribute("name",student.getStudentName());
			session.setAttribute("dept",student.getStudentDept());
			session.setAttribute("marks",student.getStudentmarks());
			session.setAttribute("mobileNum",student.getMobileNumber());
			session.setAttribute("stdPer",student.getPercentage());
			//request.getRequestDispatcher("success.html").forward(request, response);
			response.sendRedirect("./success.html");
		}
		else {
			System.out.println("invalidate");
		}
		
	}

	private boolean isvalidate(Student student) {
		List<String> validationErrors = new ArrayList<String>();
		boolean check = false;
		
		if(!(isValidName(student.getStudentName()))) {
			validationErrors.add("\n Invalid Student Name  \n");
		}
		
		if(!(isValidDept(student.getStudentDept()))){
			validationErrors.add("\n Invalid Department\n");
		}
		
		if(!(isValidMarks(student.getStudentmarks()))){
			validationErrors.add("\n Invalid Marks \n");
		}
		
		if(!(isValidMObileNumber(student.getMobileNumber()))){
			validationErrors.add("\n Invalid Mobile number \n" );
		}
		
		if(!(isValidPercentage(student.getPercentage()))){
			validationErrors.add("\n Invalid Percentage \n");
		}
		
		
		if(validationErrors.isEmpty())
		{
			check=true;
		}
		return check;
		
	}
	

	private boolean isValidPercentage(String percentage) {
		int a = Integer.parseInt(percentage);
		return a<100;
	}

	private boolean isValidMObileNumber(String mobileNumber) {
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(mobileNumber);
		return phoneMatcher.matches();
	}

	private boolean isValidMarks(String studentmarks) {
		int a = Integer.parseInt(studentmarks);
		return a<100;
	}

	private boolean isValidDept(String studentDept) {
		Pattern designPattern=Pattern.compile("^[A-Za-z]{5,}$");
		Matcher designMatcher=designPattern.matcher(studentDept);
		return designMatcher.matches();
	}


	private boolean isValidName(String Name) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,20}$");
		Matcher nameMatcher=namePattern.matcher(Name);
		return nameMatcher.matches();
	}
}


