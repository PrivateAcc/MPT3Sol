package com.distance.jpa;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DistancePersist {
	
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		double distanceMetres=0;
		double distanceMiles =0;
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		Distance distance = new Distance();
		
		System.out.println("Enter DistanceId: ");
		distance.setDistance_id(sc.nextInt());
		System.out.println("Enter Source : ");
		distance.setSource(sc.next());
		System.out.println("Enter Destination : ");
		distance.setDestination(sc.next());
		System.out.println("Enter Distance in KM: ");
		distance.setDist_in_km(sc.nextInt());
		System.out.println("Enter Distance in Meters");
		distanceMetres = sc.nextInt();
		
		distanceMiles=1.61*(distance.getDist_in_km());
		distance.setDist_in_miles(distanceMiles);
		try {
		em.getTransaction().begin();
		
		em.persist(distance);
	
		em.getTransaction().commit();
		System.out.println(distance);
		}
		catch (Exception e) {
			System.err.println("Error Happened in Persisting");
		}
		finally {
			em.close();
			factory.close();
		}
		
	}
}







